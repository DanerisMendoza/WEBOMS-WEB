<?php
    $page = 'admin';
    include('method/checkIfAccountLoggedIn.php');
    include('method/query.php');
    $_SESSION['from'] = 'salesReport';
    if(isset($_POST['fetch']) && !isset($_POST['showAll'])){
        $date1 = $_POST['dateFetch1'];
        $date2 = $_POST['dateFetch2'];
        $query = "select WEBOMS_userInfo_tb.name, WEBOMS_order_tb.* from WEBOMS_userInfo_tb, WEBOMS_order_tb where WEBOMS_userInfo_tb.userlinkId = WEBOMS_order_tb.userlinkId and WEBOMS_order_tb.status = 'complete' and WEBOMS_order_tb.date between '$date1' and '$date2' ORDER BY WEBOMS_order_tb.id asc; ";
        $resultSet =  getQuery($query); 
    }
    else{
        $query = "select WEBOMS_userInfo_tb.name, WEBOMS_order_tb.* from WEBOMS_userInfo_tb, WEBOMS_order_tb where WEBOMS_userInfo_tb.userlinkId = WEBOMS_order_tb.userlinkId and WEBOMS_order_tb.status = 'complete' ORDER BY WEBOMS_order_tb.id asc; ";
        $resultSet =  getQuery($query); 
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin SR</title>
        
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>
<body class="bg-light">

<div class="container text-center mt-5">
    <div class="row justify-content-center">
        <button class="btn btn-lg btn-dark col-4 mb-3" id="admin">Admin</button>
        <button class="btn btn-lg btn-success col-4 mb-3" id="viewGraph">View Graph</button>
        <button class="btn btn-lg btn-success col-4 mb-3" id="viewGraph">View in PDF</button>
        <div class="container-fluid">
            <form method="post">
                <div class="col-12 row">
                    <h5 class="form-control col-2">From:</h5><input type="datetime-local" name="dateFetch1" class="form-control form-control-lg mb-2 col-3" value="<?php echo(isset($_POST['dateFetch1'])?  $_POST['dateFetch1']: " ") ?>" >
                    <h5 class="form-control col-2">To:</h5><input type="datetime-local" name="dateFetch2" class="form-control form-control-lg mb-2 col-3" value="<?php echo(isset($_POST['dateFetch1'])?  $_POST['dateFetch2']: " ") ?>" >
                    <button type="submit" name="fetch" class="btn btn-lg btn-success col-2 mb-2">Fetch</button>
                </div>
                <button type="submit" name="showAll" class="btn btn-lg btn-success col-12 mb-3">Show All</button>
            </form>
        </div>
            <div class="table-responsive col-lg-12">
                <table class="table table-striped table-bordered col-lg-12">
                    <thead class="table-dark">
                        <tr>	
                            <th scope="col">NAME</th>
                            <th scope="col">TRANSACTION NO</th>
                            <th scope="col">STATUS</th>
                            <th scope="col">DATE & TIME</th>
                            <th scope="col">TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total = 0;
                        if($resultSet != null)
                            foreach($resultSet as $rows){ ?>
                                <tr>	   
                                <td><?php echo $rows['name']; ?></td>
                                <td><?php echo $rows['ordersLinkId'];?></td>
                                <td><a class="btn btn-light border-dark" href="adminOrders.php?idAndPic=<?php echo $rows['ordersLinkId'].','.$rows['proofOfPayment']?>">View Order</a></td>
                                <td><?php echo date('m/d/Y h:i a ', strtotime($rows['date'])); ?></td>
                                <td><?php echo '₱'.$rows['totalOrder']; ?></td>
                                <?php $total += $rows['totalOrder'];?>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td colspan="4"><strong>Total</strong></td>
                                <td><strong><?php echo '₱'.$total;?></strong></td>
                            </tr>
                    </tbody>
                </table>
            </div>
    </div>
</div>
    
</body>
</html>

<script>
    document.getElementById("admin").onclick = function () {window.location.replace('admin.php'); };
    document.getElementById("viewGraph").onclick = function () {window.location.replace('adminGraph.php'); };
</script>