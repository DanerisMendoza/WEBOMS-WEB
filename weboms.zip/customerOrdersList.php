<?php 
  $page = 'customer';
  include('method/checkIfAccountLoggedIn.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Costumer - View Your Orders</title>

  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
    
</head>
<body class="bg-light">
    
<div class="container text-center mt-5">
  <div class="row justify-content-center">
    <button class="btn btn-lg btn-dark col-12 mb-4" id="customer">Customer</button>
        <script>
            document.getElementById("customer").onclick = function () {window.location.replace('customer.php'); };    
        </script> 
        
    <div class="table-responsive col-lg-12">
      <table class="table table-striped table-bordered col-lg-12">
        <thead class="table-dark">
          <tr>	
            <th scope="col">NAME</th>
            <th scope="col">STATUS</th>
            <th scope="col">EMAIL</th>
            <th scope="col">FEEDBACK</th>
            <th scope="col">DATE & TIME</th>
            <th scope="col">ORDER DETAILS</th>
          </tr>
        </thead>
        <tbody>
              <?php
              include('method/query.php');
                $user_id = $_SESSION["user_id"];  
                $getCustomerOrders = "select a.name, a.email, b.* from WEBOMS_userInfo_tb a inner join WEBOMS_order_tb b on a.user_id = b.user_id where a.user_id = '$user_id' order by b.id desc;";
                $resultSet = getQuery($getCustomerOrders);
                if($resultSet != null)
                foreach($resultSet as $row){ ?>
                <tr>	   
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php 
                  $order_id = $row['order_id'];
                  $user_id = $row['user_id'];
                  $checkIfAlreadyFeedback = "SELECT * FROM WEBOMS_feedback_tb WHERE order_id='$order_id' AND user_id = '$user_id' ";
                  $resultSet = getQuery($checkIfAlreadyFeedback);
                  if($row['status'] == 'complete' && $resultSet == null){
                    ?>  <a class="btn btn-light border-dark" href="customerFeedBack.php?ordersLinkIdAndUserLinkId=<?php echo $row['order_id'].','.$row['user_id']?>">Feedback</a>  <?php
                  }
                  elseif($row['status'] == 'complete'){
                    echo "You have already feedback!";
                  }
                  else{
                    echo "Please wait until order is Complete.";
                  }
                ?>
                </td>
                <td><?php echo date('m/d/Y h:i:s a ', strtotime($row['date'])); ?></td>
                <td><a class="btn btn-light border-dark" href="customerOrders.php?id=<?php echo $row['order_id'];?>">View Order</a></td>
                </tr>
                <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
    
</body>
</html>

