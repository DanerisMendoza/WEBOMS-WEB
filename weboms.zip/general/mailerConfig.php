<?php 
//hosting
$mail->Host = 'mail.ucc-csd-bscs.com';		                //Set the SMTP server to send through
$mail->Username   = 'weboms@ucc-csd-bscs.com';              //from //SMTP username
$mail->Password   = 't74lE;+hV#Ou';    		            //SMTP password
?>