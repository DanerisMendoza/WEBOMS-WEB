<?php 
    //no hosting
    $mail->Host = 'smtp.gmail.com';		                		//Set the SMTP server to send through
    $mail->Username   = 'weboms098@gmail.com';              	//from //SMTP username
    $mail->Password   = 'budxqkjxrmenshdw';  					//SMTP password
?>