<?php 
//hosting
$mail->Host = '';		                //Set the SMTP server to send through
$mail->Username   = '';              //from //SMTP username
$mail->Password   = '';    			            //SMTP password
?>